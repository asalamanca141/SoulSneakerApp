import {Sneaker} from './sneaker';

export const SNEAKERS: Sneaker[] = [

    {
        title: 'Nike Dunk High Game Royal',
        avatar: './assets/img/0.jpg',
        details: '$120',
        image: './assets/img/0.jpg'
    },
    
    {
        title: 'Jordan 1 Retro High',
        avatar: './assets/img/1.jpg',
        details: '$170',
        image: './assets/img/1.jpg'
    },
    
    {
        title: 'Jordan 3 Retro Rust Pink (W)',
        avatar: './assets/img/2.jpg',
        details: '$190',
        image: './assets/img/2.jpg'
    },
    
    {
        title: 'Jordan 5 Retro Raging Bulls Red (2021)',
        avatar: './assets/img/3.jpg',
        details: '$190',
        image: './assets/img/3.jpg'
    },
    
    {
        title: 'Jordan 5 Retro Raging Bulls Red 2021 (GS)',
        avatar: './assets/img/4.jpg',
        details: '$140',
        image: './assets/img/4.jpg'
    },
    
    {
        title: 'Jordan 12 Retro Low Easter (2021)',
        avatar: './assets/img/5.jpg',
        details: '$200',
        image: './assets/img/5.jpg'
    },
    
    {
        title: 'Jordan 1 Retro High White University Blue Black (GS)',
        avatar: './assets/img/6.jpg',
        details: '$130',
        image: './assets/img/6.jpg'
    },

    {
        title: 'Nike Air Max 1 Evolution Of Icons',
        avatar: './assets/img/7.jpg',
        details: '$140',
        image: './assets/img/7.jpg'
    },
    
    {
        title: 'New Balance BB480 Junya Watanabe',
        avatar: './assets/img/8.jpg',
        details: '$220',
        image: './assets/img/8.jpg'
    },

    {
        title: 'Nike Air Max Pre-Day Light Liquid Lime',
        avatar: './assets/img/9.jpg',
        details: '$130',
        image: './assets/img/9.jpg'
    },

    {
        title: 'Nike Air Max 97 Swarovski Polar Blue (W)',
        avatar: './assets/img/10.jpg',
        details: '$400',
        image: './assets/img/10.jpg'
    },
    
    ];
    
    