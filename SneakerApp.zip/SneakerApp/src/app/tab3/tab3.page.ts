import { Component, OnInit } from '@angular/core';
import { HttpClient } from'@angular/common/http';


@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss']
})
export class Tab3Page implements OnInit {

  sneakerlist: any;

  constructor(private http: HttpClient) {}


  ngOnInit() {
    console.log("Inside New Page");
    this.http.get('https://api.thesneakerdatabase.com/v1/sneakers?limit=100').subscribe((response) => {
      const jsonObj: any = response;
      console.log("jsonObj results array is:");
      console.log(jsonObj.results);
      this.sneakerlist = jsonObj.results;
    });

  }

}
