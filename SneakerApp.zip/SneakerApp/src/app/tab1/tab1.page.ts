import { Component } from '@angular/core';
import { Storage } from '@ionic/storage-angular';
import { Router } from '@angular/router';



@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {

  email = ""
  password = ""
  error = false
  errorMsg = ""

  constructor(private storage: Storage, private router: Router) {}

  login() {

    this.storage.get('user').then((user) => {
      console.log(user);
      if (user) {
        if (user.email == this.email && user.password == this.password) {
          this.email = ""
          this.password = ""
          this.error = false;
          this.router.navigate(['/dashboard'])
        }
        else {
          this.email = ""
          this.password = ""

          this.error = true;
          this.errorMsg = "Email or Password is Invalid"

        }
      } else {
        this.error = true; //If user details match, the form will reset values and go to the dashboard
        this.errorMsg = "No account found. Please Register first!"
      }


    });
  }
}
