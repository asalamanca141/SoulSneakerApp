export interface Sneaker {

    title: string;
    avatar: string;
    details: string;
    image: string
    
}