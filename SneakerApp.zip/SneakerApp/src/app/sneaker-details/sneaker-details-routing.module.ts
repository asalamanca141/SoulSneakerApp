import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SneakerDetailsPage } from './sneaker-details.page';

const routes: Routes = [
  {
    path: '',
    component: SneakerDetailsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SneakerDetailsPageRoutingModule {}
