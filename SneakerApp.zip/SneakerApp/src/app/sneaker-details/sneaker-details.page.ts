import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-sneaker-details',
  templateUrl: './sneaker-details.page.html',
  styleUrls: ['./sneaker-details.page.scss'],
})
export class SneakerDetailsPage implements OnInit {

  sneaker = {};

  constructor(private route: ActivatedRoute, private router: Router) {}

  ngOnInit() {

    this.route.queryParams.subscribe(params =>
      {
        this.sneaker = this.router.getCurrentNavigation().extras.state.sneaker;
        console.log('Details Page', this.sneaker)
      }
      
      );



  }

}
