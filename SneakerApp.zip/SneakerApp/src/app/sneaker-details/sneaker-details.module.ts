import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SneakerDetailsPageRoutingModule } from './sneaker-details-routing.module';

import { SneakerDetailsPage } from './sneaker-details.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SneakerDetailsPageRoutingModule
  ],
  declarations: [SneakerDetailsPage]
})
export class SneakerDetailsPageModule {}
