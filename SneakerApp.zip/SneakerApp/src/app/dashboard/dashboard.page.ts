import { Component, OnInit } from '@angular/core';
import { Storage } from '@ionic/storage-angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.page.html',
  styleUrls: ['./dashboard.page.scss'],
})
export class DashboardPage implements OnInit {

  user = {}

  constructor(private storage: Storage, private router: Router) {}


  ngOnInit() {

    // This will allow to get the user object
    this.storage.get('user').then((obj) => {
      console.log(obj);
      this.user = obj
    });
  }

    // Delete user Object and got back to user home page
  delete(){
    this.storage.set('user', null).then((obj) => {
      this.router.navigate(['/'])
    });
  }

  // This will take user back to user home page
  logout(){
    this.router.navigate(['/'])
  }



}
