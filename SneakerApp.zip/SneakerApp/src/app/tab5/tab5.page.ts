import { Component } from '@angular/core';
import { Sneaker } from '../sneaker';
import { SNEAKERS } from '../sneakers';
import { NavigationExtras, Router } from '@angular/router';

@Component({
  selector: 'app-tab5',
  templateUrl: './tab5.page.html',
  styleUrls: ['./tab5.page.scss'],
})

export class Tab5Page {

  sneakers = SNEAKERS;
  selectedSneaker?: Sneaker;



  constructor(private router: Router) {}

  ngOnInit() {
    let selectedSneaker = {};
  }

  onSelect(sneaker) {
    this.selectedSneaker = sneaker;

    let navigationExtras: NavigationExtras = {

      state: {
        sneaker: this.selectedSneaker
      }
    };

      console.log(navigationExtras);
      this.router.navigate(['/sneaker-details'], navigationExtras)
    }

  }



  


