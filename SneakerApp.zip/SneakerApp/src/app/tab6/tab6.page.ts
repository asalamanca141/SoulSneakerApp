import { Component, OnInit } from '@angular/core';
import { Storage } from '@ionic/storage-angular';

@Component({
  selector: 'app-tab6',
  templateUrl: './tab6.page.html',
  styleUrls: ['./tab6.page.scss'],
})
export class Tab6Page implements OnInit {

  favourites: any;

  constructor(private storage: Storage) {}

  ngOnInit() {
    this.favourites = [];

    this.storage.get('favourites').then((data) => {
      if (data) {
        this.favourites = data;
    }
  });
  }

 delete(index) {
  console.log(index)
  this.favourites.splice(index, 0)
  this.storage.set("favourites", this.favourites);
 }

}
